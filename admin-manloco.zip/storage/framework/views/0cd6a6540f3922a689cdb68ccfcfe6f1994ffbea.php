<table class="table table-sm">
    <thead>
        <tr>
            <th>#Invoice</th>
            <th>: <?php echo e($invoice->no_invoice); ?></th>
        </tr>
        <tr>
            <th>Waktu</th>
            <th>: <?php echo e(date('d/m/Y H:i', strtotime($invoice->updated_at))); ?></th>
        </tr>
        <tr>
            <th>Dilayani oleh</th>
            <th>:
                <?php if($invoice->penjualanKaryawan): ?>
                    <?php $__currentLoopData = $invoice->penjualanKaryawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($k->karyawan->nama); ?>,
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endif; ?>
            </th>
        </tr>
    </thead>
</table>
<table class="table table-sm" mt-2>
    <thead>
        <tr>
            <th>#</th>
            <th>Service</th>
            <th>Harga</th>
            <th>Total</th>
        </tr>
    </thead>
    <tbody>
        <?php if($invoice->penjualan): ?>
            <?php
                $i = 1;
                $grand_total = 0;
            ?>
            <?php $__currentLoopData = $invoice->penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $grand_total += $d->qty * $d->harga;
                ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($d->qty); ?> X <?php echo e($d->service->nm_service); ?></td>
                    <td><?php echo e(number_format($d->harga, 0)); ?></td>
                    <td><?php echo e(number_format($d->qty * $d->harga, 0)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </tbody>
    <tbody>
        <tr>
            <td colspan="3"><b>Diskon</b></td>
            <td><?php echo e(number_format($invoice->diskon, 0)); ?></td>
        </tr>
    </tbody>
    <tfoot>
        <tr>
            <td colspan="3"><b>Total</b></td>
            <td><b><?php echo e(number_format($grand_total - $invoice->diskon, 0)); ?></b></td>
        </tr>
    </tfoot>
</table>
<?php /**PATH D:\programming\Laravel\manloco\resources\views/kasir/getDeatailPesanan.blade.php ENDPATH**/ ?>