<div class="table-responsive">
    <table class="table table-sm table-striped">
        <thead>
            <tr class="text-center">
                <th>Antrian</th>
                <th>Waktu</th>
                <th>Invoice</th>
                <th>Customer</th>
                <th>No WA</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $antrian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-center">
                    <td><?php echo e($d->no_antrian); ?></td>
                    <td><?php echo e(date('d/m/Y H:i', strtotime($d->created_at))); ?></td>
                    <td><?php echo e($d->no_invoice); ?></td>
                    <td><?php echo e($d->nm_customer); ?></td>
                    <td><?php echo e($d->no_tlp); ?></td>
                    <td><button class="btn btn-sm btn-primary mt-2 add_pesanan" type="button" data-bs-toggle="modal"
                            data-bs-target="#modal_add_pesanan" invoice_id="<?php echo e($d->id); ?>"><i
                                class='bx bxs-cart'></i></button> <button
                            class="btn btn-sm btn-primary mt-2 delete_pelanggan" invoice_id="<?php echo e($d->id); ?>"
                            type="button"><i class='bx bxs-trash'></i></button></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH D:\programming\Laravel\manloco\resources\views/kasir/getAntrian.blade.php ENDPATH**/ ?>