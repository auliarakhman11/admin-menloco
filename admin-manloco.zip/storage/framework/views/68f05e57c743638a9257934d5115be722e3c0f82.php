<div class="table-responsive">
    <table class="table table-sm table-striped">
        <thead>
            <tr class="text-center">
                <th>#</th>
                <th>Antrian</th>
                <th>Waktu Selesai</th>
                <th>Invoice</th>
                <th>Customer</th>
                <th>Total</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $total = 0;
                $i = 1;
            ?>
            <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $total += $d->total - $d->diskon;
                ?>
                <tr class="text-center">
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($d->no_antrian); ?></td>
                    <td><?php echo e(date('d/m/Y H:i', strtotime($d->updated_at))); ?></td>
                    <td><?php echo e($d->no_invoice); ?></td>
                    <td><?php echo e($d->nm_customer); ?></td>
                    <td><?php echo e(number_format($d->total - $d->diskon, 0)); ?></td>
                    <td>
                        <button type="button" invoice_id="<?php echo e($d->id); ?>"
                            class="btn btn-sm btn-primary detail_penjualan" data-bs-toggle="modal"
                            data-bs-target="#modal_detail_penjualan"><i class='bx bx-search'></i></button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="5"><b>Total</b></td>
                <td><b><?php echo e(number_format($total, 0)); ?></b></td>
                <td></td>
            </tr>
        </tfoot>
    </table>
</div>
<?php /**PATH D:\programming\Laravel\manloco\resources\views/laporan/detailLaporanPenjualan.blade.php ENDPATH**/ ?>