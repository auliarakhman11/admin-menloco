<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
    <div class="app-brand demo">
        <a href="" class="app-brand-link">
            <span class="app-brand-logo demo">
                <img src="<?php echo e(asset('img')); ?>/MEN_LOCO_BLACK.png" alt="" width="120" viewBox="0 0 25 42"
                    version="1.1">



            </span>

            
        </a>

        <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
            <i class="bx bx-chevron-left bx-sm align-middle"></i>
        </a>
    </div>

    <div class="menu-inner-shadow"></div>

    <ul class="menu-inner py-1">
        <!-- Dashboard -->
        




        <li class="menu-header small text-uppercase">
            <span class="menu-header-text"><i class='bx bxs-user-pin'></i> <?php echo e(Auth::user()->name); ?></span>
        </li>


        <?php if(Auth::user()->role_id == 1): ?>
            <li class="menu-item <?php echo e(Request::is(['/', 'laporanRefund']) ? 'active open' : ''); ?>">
                <a href="javascript:void(0);" class="menu-link menu-toggle">
                    <i class='menu-icon tf-icons bx bx-store'></i>
                    <div data-i18n="Penjualan">Penjualan</div>
                </a>
                <ul class="menu-sub">

                    <li class="menu-item <?php echo e(Request::is('/') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('laporanPenjualan')); ?>" class="menu-link">
                            <div data-i18n="Laporan Penjualan">Laporan Penjualan</div>
                        </a>
                    </li>

                    <li class="menu-item <?php echo e(Request::is('laporanRefund') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('laporanRefund')); ?>" class="menu-link">
                            <div data-i18n="Laporan Penjualan">Laporan Refund</div>
                        </a>
                    </li>

                </ul>
            </li>
            <li class="menu-item <?php echo e(Request::is(['user', 'service', 'karyawan', 'diskon']) ? 'active open' : ''); ?>">
                <a href="javascript:void(0);" class="menu-link menu-toggle">
                    <i class='menu-icon tf-icons bx bxs-book-content'></i>
                    <div data-i18n="Data Master">Data Master</div>
                </a>
                <ul class="menu-sub">


                    <li class="menu-item <?php echo e(Request::is('user') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('user')); ?>" class="menu-link">
                            <div data-i18n="User">User</div>
                        </a>
                    </li>

                    <li class="menu-item <?php echo e(Request::is('service') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('service')); ?>" class="menu-link">
                            <div data-i18n="Service">Service</div>
                        </a>
                    </li>

                    <li class="menu-item <?php echo e(Request::is('karyawan') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('karyawan')); ?>" class="menu-link">
                            <div data-i18n="Karyawan">Karyawan</div>
                        </a>
                    </li>

                    <li class="menu-item <?php echo e(Request::is('diskon') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('diskon')); ?>" class="menu-link">
                            <div data-i18n="diskon">Diskon</div>
                        </a>
                    </li>

                </ul>
            </li>
        <?php endif; ?>






        



        <li class="menu-item">
            <a href="<?php echo e(route('gantiPassword')); ?>" class="menu-link">
                <i class='menu-icon tf-icons bx bx-key'></i>
                <div data-i18n="Analytics">Ganti Password</div>
            </a>
        </li>

        <li class="menu-item">
            <a href="<?php echo e(route('logout')); ?>" class="menu-link">
                <i class='menu-icon tf-icons bx bx-log-out-circle'></i>
                <div data-i18n="Analytics">Logout</div>
            </a>
        </li>








    </ul>
</aside>
<?php /**PATH D:\programming\Laravel\admin-manloco\resources\views/template/_sidebar.blade.php ENDPATH**/ ?>