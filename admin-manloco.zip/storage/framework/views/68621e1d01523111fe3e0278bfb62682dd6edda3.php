<style>
    .invoice {
        margin: auto;
        width: 80mm;
        background: #FFF;
    }

    .huruf {
        font-size: 18px;
    }

    .huruf2 {
        font-size: 25px;
    }
</style>
<script>
    window.print();
</script>







<div class="invoice">
    <br>
    <center>
        <img width="150" src="<?php echo e(asset('img')); ?>/MEN_LOCO_BLACK.png" alt="">

    </center>
    <p align="center" class="huruf">Gentleman's Barber</p>
    <p style=" margin-top: -10px;" align="center" class="huruf">0813-4865-3988</p>
    
    


    <table width="100%">
        
        <tr>
            <td width="40%" class="huruf">Waktu</td>
            <td style="text-align: left; " class="huruf">: <?php echo e(date('d M Y H:i', strtotime($invoice->updated_at))); ?>

            </td>
        </tr>
        <!-- <tr>
        <td width="40%" class="huruf">Order</td>
      <td style="text-align: left; " class="huruf">: Kasir Orchard</td>
    </tr> -->
        <tr>
            <td width="40%" class="huruf">Dilayani oleh</td>
            <td style="text-align: left; font-size: 14px;" class="huruf">:
                <?php if($invoice->penjualanKaryawan): ?>
                    <?php
                        $i = 1;
                    ?>
                    <?php $__currentLoopData = $invoice->penjualanKaryawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($i > 1): ?>
                            ,
                        <?php endif; ?>
                        <?php echo e($kry->karyawan->nama); ?>

                        <?php
                            $i++;
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

            </td>
        </tr>

        <tr>
            <td width="40%" class="huruf">Costumer</td>
            <td style="text-align: left; " class="huruf">: <?php echo e($invoice->nm_customer); ?></td>
        </tr>

        

        

    </table>

    <hr>
    <?php
        $total_produk = 0;
        $qty_produk = 0;
    ?>
    <table width="100%">
        <?php $__currentLoopData = $invoice->penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="huruf" style="margin-bottom: 2px;">
                <td width="10%"><?php echo e($d->qty); ?></td>
                <td width="70%"><?php echo e(ucwords($d->service->nm_service)); ?></td>

                <td width="20%" style="text-align: right;">
                    <strong><?php echo e(number_format($d->harga * $d->qty, 0)); ?></strong>
                </td>
            </tr>
            <?php
                $total_produk += $d->harga * $d->qty;
                $qty_produk += $d->qty;
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    </table>
    <hr>
    <table width="100%">
        

        

        
        <tr class="huruf">
            <td><strong>Total <?php echo e($qty_produk); ?> Service</strong></td>
            <td style="text-align: right;"><strong><?php echo e(number_format($total_produk, 0)); ?></strong></td>
        </tr>
        <tr class="huruf">
            <td><strong>Diskon</strong></td>
            <td style="text-align: right;">
                <strong><?php echo e($invoice->diskon > 0 ? number_format($invoice->diskon, 0) : '-'); ?></strong>
            </td>
        </tr>
        <tr class="huruf">
            <td><strong>Grand Total</strong></td>
            <td style="text-align: right;"><strong><?php echo e(number_format($total_produk - $invoice->diskon, 0)); ?></strong>
            </td>
        </tr>
        

        
    </table>
    <hr>
    <hr>
    <p class="huruf" align="center">Terimakasih</p>
    
    <p class="huruf" align="center">Instagram : menloco.id</p>
    
    <p class="huruf" align="center">Terbayar</p>

    <?php
        $zona_waktu = date('d M Y h:i');

    ?>
    <p class="huruf" align="center" style="margin-top: -10px;"><-------- <?= $zona_waktu ?> --------></p>



    <!-- <script>
        var url = document.getElementById('url').value;
        var count = 5; // dalam detik
        function countDown() {
            if (count > 0) {
                count--;
                var waktu = count + 1;
                $('#pesan').html('Anda akan di redirect ke ' + url + ' dalam ' + waktu + ' detik.');
                setTimeout("countDown()", 1000);
            } else {
                window.location.href = url;
            }
        }
        countDown();
    </script>  -->
<?php /**PATH D:\programming\Laravel\manloco\resources\views/kasir/nota.blade.php ENDPATH**/ ?>