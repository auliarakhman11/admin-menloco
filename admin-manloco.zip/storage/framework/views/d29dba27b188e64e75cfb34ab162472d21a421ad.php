<div class="table-responsive">
    <table class="table table-sm table-striped">
        <thead>
            <tr class="text-center">
                <th>Antrian</th>
                <th>Waktu Selesai</th>
                <th>Invoice</th>
                <th>Customer</th>
                <th>No WA</th>
                <th>Total</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $antrian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-center">
                    <td><?php echo e($d->no_antrian); ?></td>
                    <td><?php echo e(date('d/m/Y H:i', strtotime($d->updated_at))); ?></td>
                    <td><?php echo e($d->no_invoice); ?></td>
                    <td><?php echo e($d->nm_customer); ?></td>
                    <td><?php echo e($d->no_tlp); ?></td>
                    <td><?php echo e(number_format($d->total - $d->diskon, 0)); ?></td>
                    <td>
                        <a href="<?php echo e(route('printNota', ['inv' => $d->id])); ?>" class="btn btn-sm btn-primary"><i
                                class='bx bx-printer'></i></a>
                        <button invoice_id="<?php echo e($d->id); ?>" class="btn btn-sm btn-primary refund_pesanan"
                            data-bs-toggle="modal" data-bs-target="#modal_refund"><i class='bx bx-refresh'></i></button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH D:\programming\Laravel\manloco\resources\views/kasir/getSelesai.blade.php ENDPATH**/ ?>