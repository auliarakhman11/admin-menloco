<div class="row">
    @csrf
    <div class="col-12 mb-2">
        <div class="form-group">
            <label for="">Nama Pelanggan</label>
            <input type="text" name="nm_customer" class="form-control" required>
        </div>
    </div>

    <div class="col-12 mb-2">
        <div class="form-group">
            <label for="">Nomor WA</label>
            <input type="number" name="no_tlp" class="form-control">
        </div>
    </div>


</div>
